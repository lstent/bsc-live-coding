#pragma once

struct Vertex
{
	float x, y, z;
	float r, g, b, a;
	float tu, tv;
};